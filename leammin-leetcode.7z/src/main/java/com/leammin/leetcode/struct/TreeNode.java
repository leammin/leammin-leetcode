package com.leammin.leetcode.struct;

import com.leammin.leetcode.util.TreeNodeUtils;

import java.util.Objects;

/**
 * @author Leammin
 * @date 2019-04-05
 */
public class TreeNode {
    public int val;
    public TreeNode left;
    public TreeNode right;

    public TreeNode(int x) {
        this.val = x;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        TreeNode treeNode = (TreeNode) o;
        return val == treeNode.val &&
                Objects.equals(left, treeNode.left) &&
                Objects.equals(right, treeNode.right);
    }

    @Override
    public int hashCode() {
        return Objects.hash(val, left, right);
    }

    @Override
    public String toString() {
        return TreeNodeUtils.serialize(this).toString();
    }

    public static TreeNode of(Integer... values) {
        return TreeNodeUtils.deserialize(values);
    }
}

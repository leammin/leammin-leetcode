package com.leammin.leetcode.easy;

import com.leammin.leetcode.util.AbstractTest;
import com.leammin.leetcode.util.Testsuite;

/**
 * @author Leammin
 * @date 2020-04-10
 */
class ExcelSheetColumnNumberTest extends AbstractTest<ExcelSheetColumnNumber> {
    @Override
    protected Testsuite<ExcelSheetColumnNumber> testsuite() {
        return Testsuite.<ExcelSheetColumnNumber>builder()
                .build();
    }
}
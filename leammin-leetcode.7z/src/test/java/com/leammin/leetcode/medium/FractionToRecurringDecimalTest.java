package com.leammin.leetcode.medium;

import com.leammin.leetcode.undone.medium.FractionToRecurringDecimal;
import com.leammin.leetcode.util.AbstractTest;
import com.leammin.leetcode.util.Testsuite;

/**
 * @author Leammin
 * @date 2020-04-10
 */
class FractionToRecurringDecimalTest extends AbstractTest<FractionToRecurringDecimal> {
    @Override
    protected Testsuite<FractionToRecurringDecimal> testsuite() {
        return Testsuite.<FractionToRecurringDecimal>builder()
                .build();
    }
}
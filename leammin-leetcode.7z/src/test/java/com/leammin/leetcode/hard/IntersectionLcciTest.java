package com.leammin.leetcode.hard;

import com.leammin.leetcode.undone.hard.IntersectionLcci;
import com.leammin.leetcode.util.AbstractTest;
import com.leammin.leetcode.util.Testsuite;

/**
 * @author Leammin
 * @date 2020-04-16
 */
class IntersectionLcciTest extends AbstractTest<IntersectionLcci> {
    @Override
    protected Testsuite<IntersectionLcci> testsuite() {
        return Testsuite.<IntersectionLcci>builder()
                .build();
    }
}